import os

TOKEN = os.environ.get("TOKEN")
NAME = "Axon X"
server = "https://discord.com/invite/codexdev"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [767979794411028491, 912362112620331029]
BotName = "Axon X"
serverLink = "https://discord.com/invite/codexdev"